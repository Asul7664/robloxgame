# Команды просмотра — Quiet Cove v5

Открой `QuietCove_10_Brainrots_v5.rbxlx`, запусти **Play**, дождись персонажа и включи **View → Command Bar**.
Вводи одну команду целиком и нажимай Enter. **Server и Client поддерживаются**: в Server команда передаётся в клиент текущего тестового игрока.
До запуска Play анимации недоступны; `List()` работает и в режиме редактирования.

Проверить новую позу ожидания на 6 секунд, без ловли:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Rod("Waiting", 6)
```

Посмотреть позу вываживания:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Rod("Reeling", 6)
```

Для `Rod()` также доступны `Idle`, `Charging`, `Casting`, `Bite`, `Landing`. Удочка должна быть экипирована. Продолжительность — от 1 до 20 секунд. Если начинается настоящая ловля, превью позы прекращается.

В v5 стой на месте при просмотре позы. При ходьбе специальная поза отключается сразу и используются стандартные анимации персонажа. `Idle` показывает обычное держание Tool без двухручной позы; `Waiting` — исправленное положение обеих рук во время ловли.

Проверить уменьшенную капибару: вылет из воды, затем карточка улова:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Catch("capybara")
```

Посмотреть Бобрито:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Catch("bobrito")
```

Только анимация модели Ла Вакки с сиянием:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):World("lavacca", "glow")
```

Только карточка Триппи Троппи:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Portrait("trippitroppi")
```

Золотая капибара — вылет и карточка:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Catch("capybara", "gold")
```

Все 21 персонаж по очереди — вылет и карточка:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):All()
```

Все модели по очереди, только вылет:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):All("world")
```

Все карточки по очереди:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):All("portrait")
```

Остановить просмотр и убрать его эффекты:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Stop()
```

Список ID и редкостей выводится в Output:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):List()
```

Поддерживаются варианты `"normal"`, `"gold"`, `"glow"`. Заверши текущую ловлю и закрой магазин/рюкзак перед просмотром.
Это те же локальные эффекты и карточки, что при обычной серверной поимке. Команды не выдают рыб, деньги или опыт и не меняют сохранения. `Stop()` удаляет только эффекты превью.
Клавиши **P** (карточки) и **O** (вылет) также продолжают работать в Play.

В тесте с несколькими игроками явно укажи имя последним аргументом, например:

```lua
require(game.ReplicatedStorage.QuietCove.StudioPreview):Catch("capybara", "normal", "Player1")
```

Имена можно посмотреть в Explorer → Players. В обычном Play с одним игроком дополнительный аргумент не нужен.

Если команда сообщает об отсутствии клиента, проверь **Output**: LocalScript игры должен загрузиться без ошибок. В v4 команда получает работающий обработчик через `BindableFunction` в PlayerScripts, поэтому отдельный контекст `require` у Command Bar не теряет подключённые анимации.

## ID всех персонажей

| ID | Название |
|---|---|
| capybara | Капибара |
| skibidi | Скибиди-шпрот |
| sigma | Сигма-сардина |
| ballerina | Балерина Капуччина |
| tralalero | Тралалелетралала |
| patapim | БР-БР Патапим |
| ambalabu | Бонека Амбалабу |
| bombardiro | Бомбардиро Крокофиш |
| sahur | Тун Тун Сахур |
| gigachad | Гигачад-акула |
| verity | Верити |
| floppa | Флоппа-карась |
| chipichapa | Чипи Чапа |
| bobrito | Бобрито Бандито |
| trippitroppi | Триппи Троппи |
| bombombini | Бомбомбини Гусини |
| cappuccino | Капуччино Ассассино |
| lirili | Лирили Ларила |
| chimpanzini | Чимпанзини Бананини |
| frigocamelo | Фриго Камело |
| lavacca | Ла Вакка Сатурно Сатурнита |

## PNG-портреты

Подготовлено подключение новых PNG **без Roblox asset ID** — тем же встроенным способом, что у капибары.
Портрет имеет приоритет перед 3D-превью и используется и в карточке поимки, и в рюкзаке/коллекции. До поимки иконка остаётся силуэтом с вопросительным знаком.
Пока конкретные новые PNG не встроены: изображения были видны в чате, но исходные файлы не были доступны для чтения в среде. До получения файлов у новых видов показываются прежние 3D-портреты. Исходные картинки старых видов сохранены.

Для следующей сборки приложи PNG именно файлами. Первые два будут назначены как `lavacca.png` и `trippitroppi.png`; другие можно прислать позже. ID загруженных в Roblox изображений не нужны.

Для повторной сборки в текущей облачной среде: помести файлы в `quiet-cove-expansion/portraits/<id>.png` и запусти `python3 quiet-cove-expansion/integrate.py`. Энкодер сохраняет пропорции и прозрачность на полотне 320×320, как в исходной игре; RGB сохраняется в палитре из 256 цветов, альфа — отдельными сериями. Оригинальные PNG остаются нетронутыми.
