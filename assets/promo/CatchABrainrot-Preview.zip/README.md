# Catch a Brainrot — preview

The latest promotional thumbnail, without the gold Legendary badge.

![Catch a Brainrot](CatchABrainrot-NoBadge.png)

The PNG is the finished full-resolution image. Download it directly or open it
with an ordinary image viewer. This repository contains artwork only.
